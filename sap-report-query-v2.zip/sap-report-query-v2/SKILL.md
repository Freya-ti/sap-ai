---
name: sap-report-query
description: 通过 PyRFC 连接 SAP 系统，调用 Z_AI_RUN_REPORT_WITH_PARAMS 函数模块执行 ABAP 报表（如 ZSD027），提取 ALV 或 LIST 输出数据并保存到本地 Excel。当用户需要查询 SAP 报表数据、导出 SAP 报表到 Excel、或提到"执行报表""查询报表""report ZSD""variant"时使用此 skill。
---

# SAP 报表数据查询与 Excel 导出

## 任务目标

通过 PyRFC 连接 SAP 系统，调用 RFC 函数模块 `Z_AI_RUN_REPORT_WITH_PARAMS` 执行指定 ABAP 报表程序，提取 ALV 或 LIST 输出数据并保存到本地 Excel 文件。

## 前置条件

### 环境依赖
- Python 3.12 已安装（与 `sap-ai-init` 本地 pyrfc wheel 匹配）
- 已先运行 `sap-ai-init` 完成 SDK、`pyrfc`、`python-dotenv` 配置
- `openpyxl` 已安装 (`pip install openpyxl`)
- SAP NW RFC SDK 位于 `~/.sap-ai-init/nwrfcsdk/bin`，必要时重启终端使 PATH 生效

### SAP 函数模块
`Z_AI_RUN_REPORT_WITH_PARAMS` 必须在目标 SAP 系统中存在且可用。该函数模块通过 `cl_salv_bs_runtime_info` 拦截报表的 ALV 输出数据，支持 CL_SALV_TABLE 和部分 FM 式 ALV 报表。

## 脚本位置与执行目录

本 skill 需要运行的脚本都位于 **sap-report-query skill 目录** 下，不在用户当前执行目录或业务项目目录下。

- 调用脚本时，以本文末尾 **资源索引** 中列出的脚本位置为准；如果资源索引里的脚本路径更新，优先使用更新后的路径。
- 使用运行环境加载 skill 后提供的 Base directory / skill 根目录作为 `SAP_REPORT_QUERY_SKILL_DIR`。
- Cherry Studio 中 skill 通常位于当前工作目录的 `.claude/skills/sap-report-query/` 或 `.claude/skills/sap-report-query-v2/`；如果运行环境没有显式给出 Base directory，先从工作目录下的 `.claude/skills/` 定位当前 skill 目录。
- 运行资源索引中的 `sap_report_query.py`、`get_report_params.py` 时，必须把命令工作目录设为 `SAP_REPORT_QUERY_SKILL_DIR`，或使用资源索引脚本路径解析出的绝对路径。
- 在 OpenCode 中使用 Bash 工具时，设置 `workdir` 为当前加载的 sap-report-query skill 的 Base directory。
- 不要假设用户当前目录下存在 `scripts/`，也不要在用户目录或项目目录下查找这些脚本。

## 连接配置

SAP 连接参数从 `sap-ai-init` 的 `connections.json` 读取：

- Windows: `%USERPROFILE%\.sap-ai-init\connections.json`
- Linux/Mac: `~/.sap-ai-init/connections.json`

**多系统支持**：
```json
{
  "s4qclnt300": {
    "default": true,
    "ASHOST": "10.30.31.166",
    "SYSNR": "00",
    "CLIENT": "110",
    "USER": "username",
    "PASSWORD": "password",
    "LANG": "ZH"
  },
  "s4prd": {
    "default": false,
    "ASHOST": "10.30.31.170",
    "SYSNR": "01",
    "CLIENT": "200",
    "USER": "username",
    "PASSWORD": "password",
    "LANG": "ZH"
  }
}
```

**连接确认规则**：当用户未明确指定 SAP 系统/连接名时，不要直接使用脚本记住的上次连接。先列出可用连接并让用户确认要查询的系统，避免误查到 QAS/DEV/PRD 等错误环境。只有用户本轮明确指定系统，或确认了要用哪个连接后，才执行查询并带上 `--connection` 参数。

**连接记忆**：脚本会记住用户上次选择的连接（保存在 `~/.sap-ai-init/last_used_connection.json`），但 AI 工作流不得把它当作用户确认；它只用于脚本层面的默认值，不用于替代人工确认。

## AI 工作流程

### 用户未指定 SAP 系统/连接名

1. **先列出可用系统并暂停查询**：读取或通过脚本错误提示获取连接清单，向用户展示连接名、服务器、客户端等可识别信息。
   ```
   可用 SAP 连接:
     - s4qclnt300 (default): 10.30.31.166 (CLIENT: 110)
     - s4prd: 10.30.31.170 (CLIENT: 200)
   
   请确认要查询哪个 SAP 系统？推荐：如果用户提到 s4d/s4q/s4p 等环境缩写，选择最匹配的连接名。
   ```

2. **等待用户确认**：不要在未确认前执行报表查询。

3. **执行查询**：用户确认后，命令必须带上 `--connection` 参数。
   ```bash
   python .claude/scripts/sap_report_query.py --report ZSD027 --connection s4prd
   ```

### 用户已明确指定 SAP 系统/连接名

直接使用用户指定或确认的连接，并带上 `--connection` 参数：
```bash
python scripts/sap_report_query.py --report ZSD027 --connection s4qclnt300
```

如果用户给的是环境简称（如 `s4d`）但不是完整连接名，先匹配可用连接；只有唯一明确匹配时才继续，否则列出候选项让用户确认。

### 切换系统

```bash
python scripts/sap_report_query.py --report ZSD027 --connection s4qclnt300
```

## 操作步骤

### 1. 获取报表参数定义（推荐）

```bash
# 获取报表参数列表（文本格式）
# 工作目录必须是 sap-report-query skill 目录
python scripts/get_report_params.py --report ZSD027

# 获取报表参数列表（JSON 格式）
# 工作目录必须是 sap-report-query skill 目录
python scripts/get_report_params.py --report ZSD027 --json
```

### 2. 构建选择参数

```bash
# 单个参数
--params "S_VKORG:S:I:EQ:1011"

# 多个参数用逗号分隔
--params "S_VKORG:S:I:EQ:1011,S_MATNR:S:I:EQ:MAT-001"

# 范围查询
--params "S_MATNR:S:I:BT:MAT-001:MAT-100"
```

**参数格式说明：**
| 位置 | 含义 | 示例 |
|------|------|------|
| `SELNAME` | 参数名 | `S_VKORG` |
| `KIND` | 类型 (`S`=选择范围，`P`=单值) | `S` |
| `SIGN` | `I`=包含，`E`=排除 | `I` |
| `OPTION` | `EQ`=等于，`BT`=范围，`NE`=不等于 | `EQ` |
| `LOW` | 下限值 | `1011` |
| `HIGH` | 上限值（仅 `BT` 需要） | `MAT-100` |

### 3. 执行查询脚本

```bash
# 完整命令
# 工作目录必须是 sap-report-query skill 目录
python scripts/sap_report_query.py \
    --report ZSD027 \
    --variant MM1010 \
    --params "S_VKORG:S:I:EQ:1011" \
    --max-rows 100
```

## Z_AI_RUN_REPORT_WITH_PARAMS 接口说明

核心参数：

| 参数 | 类型 | 方向 | 说明 |
|------|------|------|------|
| IV_REPORT | RSVAR-REPORT | 导入 | 报表程序名（必需） |
| IV_VARIANT | RSVAR-VARIANT | 导入 | 选择变体（可选） |
| IV_MAX_ROWS | I | 导入 | 最大行数，默认 100；传 0 表示全部 |
| IT_PARAMS | RSPARAMS | 表 | 选择屏幕参数（可选） |
| ET_COLUMNS | LVC_S_FCAT | 表 | ALV 字段目录 |
| ET_DATA | SOLISTI1 | 表 | 输出数据（TAB 分隔） |
| EV_SUBRC | SY-SUBRC | 导出 | 返回码（0=成功） |
| EV_MESSAGE | BAPI_MSG | 导出 | 消息 |

## 数据格式

ET_DATA 的数据格式：
- **第 1 行**：字段名表头（TAB 分隔）
- **第 2 行起**：数据行（TAB 分隔）

脚本自动跳过表头行，使用 ET_COLUMNS 作为字段名解析数据。如果 ET_COLUMNS 为空但 ET_DATA 有内容，则按 LIST 回退模式导出为单列 `LINE`。

## 使用示例

### 示例 1: 第一次查询（指定系统）
```bash
python scripts/sap_report_query.py --report ZSD027 --connection s4prd
```
输出：
```
正在使用 SAP 连接：s4prd
  服务器：10.30.31.170
  实例：01
  客户端：200
  用户：username
...
SAP 系统：s4prd
```

### 示例 2: 后续查询（自动使用上次选择的系统）
```bash
python scripts/sap_report_query.py --report ZSD027
```

### 示例 3: 切换系统
```bash
python scripts/sap_report_query.py --report ZSD027 --connection s4qclnt300
```

### 示例 4: 重置系统选择
```bash
python scripts/sap_report_query.py --report ZSD027 --reset
```

## 常见问题

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| "No output available" | 报表无可捕获输出，或缺少选择条件/variant | 提供 variant 或完整选择参数后重试 |
| "report_not_existent" | 报表名错误或不存在 | 检查报表名是否正确 |
| "no_selections" | 报表无选择屏幕 | 该报表无选择参数，直接执行 |
| 连接超时 | 网络/端口不通 | 检查 SAP ICM 端口和 RFC 端口 |
| 缺少 SAP 连接配置 | 未运行 sap-ai-init | 运行 `sap-ai-init` 并添加连接 |
| 没有可用连接 | connections.json 为空 | 运行 `python scripts/sap_ai_init.py add` 添加连接 |
| ICU DLL 缺失 | PATH 未包含 SDK bin 目录 | 重启终端或重新运行 `sap-ai-init` |
| 参数名不匹配 | 参数名不是 Z_AI_GET_PROGRAM_PARAMS 返回的 NAME | 先运行 `get_report_params.py` 获取正确参数名 |
| Excel 列宽过大 | 100+ 字段超宽 | 脚本限制最大列宽 30 字符 |

## 资源索引

调用脚本时以本节列出的路径为准；这些路径变更时，同步更新调用命令。

- 脚本：
  - `.claude/skills/sap-report-query-v2/scripts/sap_report_query.py` — 主执行脚本
  - `.claude/skills/sap-report-query-v2/scripts/get_report_params.py` — 获取报表参数清单
- 函数模块：
  - `Z_AI_RUN_REPORT_WITH_PARAMS` — 执行报表并获取数据
  - `Z_AI_GET_PROGRAM_PARAMS` — 获取报表选择屏幕参数定义
