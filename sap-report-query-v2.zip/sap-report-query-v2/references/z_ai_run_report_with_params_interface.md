# Z_AI_RUN_REPORT_WITH_PARAMS 函数模块接口详解

## 基本信息

| 属性 | 值 |
|------|-----|
| 函数模块名 | Z_AI_RUN_REPORT_WITH_PARAMS |
| 函数组 | ZFG_TEST_VSCODE |
| 系统 | S4Q (client 300) |
| RFC启用 | 是 |

## 工作原理

Z_AI_RUN_REPORT_WITH_PARAMS 通过 `SUBMIT (iv_report)` 动态提交 ABAP 报表程序，并使用 `cl_salv_bs_runtime_info` 拦截 ALV 输出数据。

执行流程：
1. 验证报表程序存在（查 TRDIR 表）
2. 设置 `cl_salv_bs_runtime_info`（关闭显示，开启元数据和数据捕获）
3. 根据参数组合 SUBMIT 报表（variant + selection-table）
4. 尝试获取 ALV 数据（`get_data_ref` → 字段目录 + 数据行）
5. ALV 模式失败时回退到 LIST_FROM_MEMORY + LIST_TO_ASCI

## 参数接口

### 导入参数 (IMPORTING)

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| IV_REPORT | RSVAR-REPORT | 必填 | ABAP 报表程序名（如 ZSD027） |
| IV_VARIANT | RSVAR-VARIANT | SPACE | SAP 选择变体名（可选） |
| IV_MAX_ROWS | I | 100 | 最大返回行数，0=不限制 |

### 导出参数 (EXPORTING)

| 参数 | 类型 | 说明 |
|------|------|------|
| EV_SUBRC | SY-SUBRC | 返回码：0=成功，4=无输出，8=SUBMIT异常 |
| EV_MESSAGE | BAPI_MSG | 结果消息，格式："OK. Mode: ALV. Rows: N" 或错误描述 |

### 表参数 (TABLES)

| 参数 | 参照类型 | 说明 |
|------|----------|------|
| IT_PARAMS | RSPARAMS | 选择屏幕参数（可选） |
| ET_COLUMNS | LVC_S_FCAT | ALV 字段目录（FIELDNAME 等属性） |
| ET_DATA | SOLISTI1 | 输出数据（LINE 字段，TAB分隔） |

## RSPARAMS 结构

| 字段 | 类型 | 说明 |
|------|------|------|
| SELNAME | CHAR 8 | 选择参数名（如 S_VKORG、P2） |
| KIND | CHAR 1 | S=Select-Option, P=Parameter |
| SIGN | CHAR 1 | I=Include, E=Exclude |
| OPTION | CHAR 2 | EQ=等于, NE=不等于, BT=区间, CP=包含模式 |
| LOW | CHAR 45 | 低值 |
| HIGH | CHAR 45 | 高值（BT选项时使用） |

## ET_DATA 数据格式

ALV 模式输出：
- 第1行：字段名表头，TAB分隔（如 `EBELN\tVKORG\tLFART\t...`）
- 第2行起：数据行，TAB分隔，每列对应 ET_COLUMNS 中 FIELDNAME 的顺序

LIST 模式输出（回退）：
- 直接为 ABAP 列表文本行，无结构化解析

## 返回码说明

| EV_SUBRC | 含义 | 处理建议 |
|----------|------|----------|
| 0 | 成功 | 正常解析数据 |
| 4 | 无输出 | 检查报表是否使用 FM 式 ALV，需提供 variant |
| 8 | SUBMIT 异常 | 检查报表名称和参数是否正确 |

## 典型调用示例

```python
# 使用 variant 调用
result = conn.call(
    'Z_AI_RUN_REPORT_WITH_PARAMS',
    IV_REPORT='ZSD027',
    IV_VARIANT='MM1010',
    IV_MAX_ROWS=0,
)

# 使用选择参数调用
it_params = [
    {'SELNAME': 'S_VKORG', 'KIND': 'S', 'SIGN': 'I', 'OPTION': 'EQ', 'LOW': '1011', 'HIGH': ''},
]
result = conn.call(
    'Z_AI_RUN_REPORT_WITH_PARAMS',
    IV_REPORT='ZSD027',
    IV_MAX_ROWS=5000,
    IT_PARAMS=it_params,
)
```

## 限制与注意事项

1. **FM 式 ALV 兼容性**：部分使用 `REUSE_ALV_GRID_DISPLAY_LVC` 的报表需要提供 variant 或完整选择参数，否则可能无法产生可捕获输出
2. **CL_SALV_TABLE 报表**：直接兼容，无需 variant
3. **列表输出报表**：回退到 LIST_FROM_MEMORY，输出为纯文本而非结构化数据
4. **大数据量**：IV_MAX_ROWS 建议设置上限（如 5000），避免 SAP 内存溢出
