#!/usr/bin/env python3
"""
调用 Z_AI_GET_PROGRAM_PARAMS 获取报表选择屏幕参数清单
"""

import argparse
import json
import os
import sys

SAP_AI_INIT_DIR = os.path.join(os.path.expanduser('~'), '.sap-ai-init')
SAP_AI_INIT_CONNECTIONS_PATH = os.path.join(SAP_AI_INIT_DIR, 'connections.json')
SAP_AI_INIT_SDK_BIN = os.path.join(SAP_AI_INIT_DIR, 'nwrfcsdk', 'bin')

if os.path.isdir(SAP_AI_INIT_SDK_BIN):
    os.environ['PATH'] = SAP_AI_INIT_SDK_BIN + os.pathsep + os.environ.get('PATH', '')
elif os.environ.get('SAP_NWRFCSDK_PATH'):
    os.environ['PATH'] = os.environ['SAP_NWRFCSDK_PATH'] + os.pathsep + os.environ.get('PATH', '')

from pyrfc import Connection

try:
    from dotenv import load_dotenv
except ImportError:
    print("请安装 python-dotenv: pip install python-dotenv")
    sys.exit(1)


def load_connection_params(connection_name=None):
    """从 sap-ai-init connections.json 加载连接参数"""
    if os.path.exists(SAP_AI_INIT_CONNECTIONS_PATH):
        try:
            with open(SAP_AI_INIT_CONNECTIONS_PATH, 'r', encoding='utf-8') as f:
                connections = json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            raise RuntimeError(f"无法读取 connections.json: {e}")
        
        if not connections:
            raise RuntimeError(
                "connections.json 中没有配置连接。\n"
                "请先运行 sap-ai-init 添加连接："
                "python scripts/sap_ai_init.py add"
            )
        
        if connection_name:
            if connection_name not in connections:
                available = list(connections.keys())
                raise RuntimeError(
                    f"连接 '{connection_name}' 不存在。\n"
                    f"可用连接：{', '.join(available)}"
                )
            config = connections[connection_name]
        else:
            default_conn = None
            for name, conn_config in connections.items():
                if conn_config.get('default', False):
                    default_conn = name
                    break
            
            if default_conn is None:
                available = list(connections.keys())
                raise RuntimeError(
                    "没有配置默认连接。\n"
                    f"可用连接：{', '.join(available)}\n"
                    "请设置默认连接：python scripts/sap_ai_init.py default <name>"
                )
            config = connections[default_conn]
        
        required = ['ASHOST', 'SYSNR', 'CLIENT', 'USER', 'PASSWORD']
        missing = [name for name in required if not config.get(name)]
        if missing:
            raise RuntimeError(f"连接配置缺少：{', '.join(missing)}")
        
        conn_params = {
            'ashost': config['ASHOST'],
            'sysnr': config['SYSNR'],
            'client': config['CLIENT'],
            'user': config['USER'],
            'passwd': config['PASSWORD'],
            'lang': config.get('LANG', 'ZH'),
        }
        
        if config.get('GWSERV'):
            conn_params['gwserv'] = config['GWSERV']
        
        return conn_params
    
    SAP_AI_INIT_ENV_PATH = os.path.join(SAP_AI_INIT_DIR, '.env')
    load_dotenv(SAP_AI_INIT_ENV_PATH)
    
    required = ['ASHOST', 'SYSNR', 'CLIENT', 'USER', 'PASSWORD']
    missing = [name for name in required if not os.getenv(name)]
    if missing:
        raise RuntimeError(
            f"缺少 SAP 连接配置：{', '.join(missing)}。\n"
            f"请先运行 sap-ai-init，并配置 {SAP_AI_INIT_ENV_PATH}"
        )
    
    conn_params = {
        'ashost': os.getenv('ASHOST'),
        'sysnr': os.getenv('SYSNR'),
        'client': os.getenv('CLIENT'),
        'user': os.getenv('USER'),
        'passwd': os.getenv('PASSWORD'),
        'lang': os.getenv('LANG', 'ZH'),
    }
    
    gwserv = os.getenv('GWSERV')
    if gwserv:
        conn_params['gwserv'] = gwserv
    
    return conn_params


def get_report_params(report_name, language='1', connection_name=None):
    """调用 Z_AI_GET_PROGRAM_PARAMS 获取报表参数清单"""
    conn = Connection(**load_connection_params(connection_name))
    
    try:
        result = conn.call('Z_AI_GET_PROGRAM_PARAMS', IV_REPORT=report_name, IV_LANGU=language)
        return result.get('ET_SELECTIONS', [])
    except Exception as e:
        print(f"调用 Z_AI_GET_PROGRAM_PARAMS 失败：{e}")
        raise
    finally:
        conn.close()


def format_params_display(params):
    """格式化参数列表为易读字符串"""
    if not params:
        return "该报表没有选择屏幕参数"
    
    lines = []
    lines.append(f"报表参数清单 ({len(params)} 个参数):")
    lines.append("-" * 80)
    
    for p in params:
        name = p.get('NAME', '')
        kind = p.get('KIND', '')
        screen_text = p.get('SCREEN_TEXT', '')
        dbfield = p.get('DBFIELD', '')
        obligatory = p.get('OBLIGATORY', '')
        
        kind_desc = '选择范围' if kind == 'S' else '单值参数'
        oblig_desc = '必输' if obligatory else '可选'
        
        line = f"  {name:20s} ({kind_desc}, {oblig_desc})"
        if screen_text:
            line += f" - {screen_text}"
        if dbfield:
            line += f" [DB: {dbfield}]"
        
        lines.append(line)
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description='获取 SAP 报表的选择屏幕参数')
    parser.add_argument('--report', required=True, help='报表程序名 (如 ZSD027)')
    parser.add_argument('--langu', default='1', help='语言代码，默认 1 (中文)')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    parser.add_argument('--connection', default=None, help='连接名称（不传则使用默认连接）')
    
    args = parser.parse_args()
    
    try:
        params = get_report_params(args.report, args.langu, args.connection)
        
        if args.json:
            print(json.dumps(params, ensure_ascii=False, indent=2))
        else:
            print(format_params_display(params))
    
    except Exception as e:
        print(f"错误：{e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
