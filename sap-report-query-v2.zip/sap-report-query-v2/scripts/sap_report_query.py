#!/usr/bin/env python3
"""
SAP 报表数据查询与 Excel 导出

通过 PyRFC 连接 SAP 系统，调用 Z_AI_RUN_REPORT_WITH_PARAMS 函数模块执行 ABAP 报表，
提取 ALV 输出数据并保存到本地 Excel 文件。
"""

import argparse
import json
import os
import sys
from datetime import datetime

SAP_AI_INIT_DIR = os.path.join(os.path.expanduser('~'), '.sap-ai-init')
SAP_AI_INIT_CONNECTIONS_PATH = os.path.join(SAP_AI_INIT_DIR, 'connections.json')
SAP_AI_INIT_SDK_BIN = os.path.join(SAP_AI_INIT_DIR, 'nwrfcsdk', 'bin')
USER_SELECTED_CONNECTION_PATH = os.path.join(SAP_AI_INIT_DIR, 'last_used_connection.json')

if os.path.isdir(SAP_AI_INIT_SDK_BIN):
    os.environ['PATH'] = SAP_AI_INIT_SDK_BIN + os.pathsep + os.environ.get('PATH', '')
elif os.environ.get('SAP_NWRFCSDK_PATH'):
    os.environ['PATH'] = os.environ['SAP_NWRFCSDK_PATH'] + os.pathsep + os.environ.get('PATH', '')

from pyrfc import Connection

try:
    from dotenv import load_dotenv
except ImportError:
    print("请安装 python-dotenv: pip install python-dotenv，或先运行 sap-ai-init 初始化")
    sys.exit(1)

try:
    import openpyxl
    from openpyxl.utils import get_column_letter
    from openpyxl.styles import Font, Alignment, PatternFill
except ImportError:
    print("请安装 openpyxl: pip install openpyxl")
    sys.exit(1)


def load_connection_params(connection_name=None):
    """Load SAP connection parameters from sap-ai-init connections.json."""
    if os.path.exists(SAP_AI_INIT_CONNECTIONS_PATH):
        try:
            with open(SAP_AI_INIT_CONNECTIONS_PATH, 'r', encoding='utf-8') as f:
                connections = json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            raise RuntimeError(f"无法读取 connections.json: {e}")
        
        if not connections:
            raise RuntimeError(
                "connections.json 中没有配置连接。\n"
                "请先运行 sap-ai-init 添加连接："
                "python scripts/sap_ai_init.py add"
            )
        
        if connection_name:
            if connection_name not in connections:
                available = list(connections.keys())
                raise RuntimeError(
                    f"连接 '{connection_name}' 不存在。\n"
                    f"可用连接：{', '.join(available)}"
                )
            config = connections[connection_name]
        else:
            default_conn = None
            for name, conn_config in connections.items():
                if conn_config.get('default', False):
                    default_conn = name
                    break
            
            if default_conn is None:
                available = list(connections.keys())
                raise RuntimeError(
                    "没有配置默认连接。\n"
                    f"可用连接：{', '.join(available)}\n"
                    "请设置默认连接：python scripts/sap_ai_init.py default <name>"
                )
            config = connections[default_conn]
        
        required = ['ASHOST', 'SYSNR', 'CLIENT', 'USER', 'PASSWORD']
        missing = [name for name in required if not config.get(name)]
        if missing:
            raise RuntimeError(f"连接配置缺少：{', '.join(missing)}")
        
        conn_params = {
            'ashost': config['ASHOST'],
            'sysnr': config['SYSNR'],
            'client': config['CLIENT'],
            'user': config['USER'],
            'passwd': config['PASSWORD'],
            'lang': config.get('LANG', 'ZH'),
        }
        
        if config.get('GWSERV'):
            conn_params['gwserv'] = config['GWSERV']
        
        return conn_params
    
    SAP_AI_INIT_ENV_PATH = os.path.join(SAP_AI_INIT_DIR, '.env')
    load_dotenv(SAP_AI_INIT_ENV_PATH)
    
    required = ['ASHOST', 'SYSNR', 'CLIENT', 'USER', 'PASSWORD']
    missing = [name for name in required if not os.getenv(name)]
    if missing:
        raise RuntimeError(
            f"缺少 SAP 连接配置：{', '.join(missing)}。\n"
            f"请先运行 sap-ai-init，并配置 {SAP_AI_INIT_ENV_PATH}"
        )
    
    conn_params = {
        'ashost': os.getenv('ASHOST'),
        'sysnr': os.getenv('SYSNR'),
        'client': os.getenv('CLIENT'),
        'user': os.getenv('USER'),
        'passwd': os.getenv('PASSWORD'),
        'lang': os.getenv('LANG', 'ZH'),
    }
    
    gwserv = os.getenv('GWSERV')
    if gwserv:
        conn_params['gwserv'] = gwserv
    
    return conn_params


def get_connections_info():
    """获取所有连接信息（用于显示）"""
    if os.path.exists(SAP_AI_INIT_CONNECTIONS_PATH):
        try:
            with open(SAP_AI_INIT_CONNECTIONS_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {}


def get_user_selected_connection():
    """获取用户上次选择的连接"""
    if os.path.exists(USER_SELECTED_CONNECTION_PATH):
        try:
            with open(USER_SELECTED_CONNECTION_PATH, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get('connection')
        except (json.JSONDecodeError, IOError):
            pass
    return None


def save_user_selected_connection(connection_name):
    """保存用户选择的连接"""
    try:
        with open(USER_SELECTED_CONNECTION_PATH, 'w', encoding='utf-8') as f:
            json.dump({'connection': connection_name}, f, ensure_ascii=False, indent=2)
        return True
    except IOError:
        return False


def parse_params(params_str):
    """
    解析命令行选择参数
    格式：SELNAME:KIND:SIGN:OPTION:LOW:HIGH
    """
    it_params = []
    if not params_str:
        return it_params
    
    for item in params_str.split(','):
        parts = item.split(':')
        if len(parts) >= 5:
            it_params.append({
                'SELNAME': parts[0],
                'KIND': parts[1],
                'SIGN': parts[2],
                'OPTION': parts[3],
                'LOW': parts[4],
                'HIGH': parts[5] if len(parts) > 5 else '',
            })
    return it_params


def execute_report(report, variant='', max_rows=100, it_params=None, connection_name=None):
    """连接 SAP 并执行 Z_AI_RUN_REPORT_WITH_PARAMS"""
    conn = Connection(**load_connection_params(connection_name))
    
    kwargs = {'IV_REPORT': report, 'IV_MAX_ROWS': max_rows}
    if variant:
        kwargs['IV_VARIANT'] = variant
    if it_params:
        kwargs['IT_PARAMS'] = it_params
    
    result = conn.call('Z_AI_RUN_REPORT_WITH_PARAMS', **kwargs)
    conn.close()
    return result


def parse_alv_data(et_columns, et_data):
    """解析 Z_AI_RUN_REPORT_WITH_PARAMS 返回的数据"""
    if not et_data:
        return [], []
    
    if not et_columns:
        rows = [{'LINE': row.get('LINE', '')} for row in et_data]
        return rows, ['LINE']
    
    col_mapping = []
    for c in et_columns:
        fieldname = c['FIELDNAME']
        outputtext = fieldname
        for text_field in ['REPTEXT', 'SELTEXT']:
            txt = c.get(text_field, '').strip()
            if txt:
                outputtext = txt
                break
        col_mapping.append((fieldname, outputtext))
    
    fieldnames = [fname for fname, _ in col_mapping]
    header_texts = [text for _, text in col_mapping]
    rows_parsed = []
    
    for i, row in enumerate(et_data):
        line = row['LINE']
        parts = line.split('\t')
        parts = [p.strip() for p in parts]
        
        if i == 0:
            continue
        
        row_dict = {}
        for j, fieldname in enumerate(fieldnames):
            row_dict[fieldname] = parts[j] if j < len(parts) else ''
        rows_parsed.append(row_dict)
    
    return rows_parsed, header_texts


def export_excel(rows_parsed, fieldnames, header_texts, output_dir, report_name, variant=''):
    """导出数据到 Excel 文件"""
    os.makedirs(output_dir, exist_ok=True)
    
    variant_suffix = f'_{variant}' if variant else ''
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_file = os.path.join(output_dir, f'{report_name}{variant_suffix}_{timestamp}.xlsx')
    
    wb = openpyxl.Workbook()
    ws = wb.active
    if ws is None:
        ws = wb.create_sheet()
    ws.title = report_name
    
    header_font = Font(bold=True, size=11, color='FFFFFF')
    header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    subheader_font = Font(bold=True, size=10, color='000000')
    subheader_fill = PatternFill(start_color='D9E1F1', end_color='D9E1F1', fill_type='solid')
    
    for col_idx, header_text in enumerate(header_texts, 1):
        cell = ws.cell(row=1, column=col_idx, value=header_text)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
    
    for col_idx, fieldname in enumerate(fieldnames, 1):
        cell = ws.cell(row=2, column=col_idx, value=fieldname)
        cell.font = subheader_font
        cell.fill = subheader_fill
        cell.alignment = Alignment(horizontal='center')
    
    for row_idx, row in enumerate(rows_parsed, 3):
        for col_idx, fieldname in enumerate(fieldnames, 1):
            ws.cell(row=row_idx, column=col_idx, value=row.get(fieldname, ''))
    
    for col_idx in range(1, len(fieldnames) + 1):
        max_len = len(str(ws.cell(row=1, column=col_idx).value or ''))
        max_len = max(max_len, len(str(ws.cell(row=2, column=col_idx).value or '')))
        for row_idx in range(3, min(len(rows_parsed) + 3, 52)):
            cell_val = str(ws.cell(row=row_idx, column=col_idx).value or '')
            max_len = max(max_len, min(len(cell_val), 30))
        ws.column_dimensions[get_column_letter(col_idx)].width = max_len + 2
    
    ws.row_dimensions[1].height = 25
    ws.row_dimensions[2].height = 20
    
    wb.save(output_file)
    return output_file


def main():
    parser = argparse.ArgumentParser(description='SAP 报表数据查询与 Excel 导出')
    parser.add_argument('--report', required=True, help='ABAP 报表程序名（如 ZSD027）')
    parser.add_argument('--variant', default='', help='SAP 选择变体名（如 MM1010）')
    parser.add_argument('--max-rows', type=int, default=100, help='最大返回行数（默认 100，0=全部）')
    parser.add_argument('--params', default='', help='选择参数，格式：SELNAME:KIND:SIGN:OPTION:LOW:HIGH，多个用逗号分隔')
    parser.add_argument('--output-dir', default='', help='输出目录（默认：用户桌面）')
    parser.add_argument('--connection', default=None, help='连接名称')
    parser.add_argument('--reset', action='store_true', help='重置已保存的连接选择')
    
    args = parser.parse_args()
    
    if not args.output_dir:
        args.output_dir = os.path.join(os.path.expanduser('~'), 'Desktop')
    
    it_params = parse_params(args.params)
    connections = get_connections_info()
    
    # 确定连接名称
    connection_name = args.connection
    
    # 如果指定了 --reset，删除已保存的连接选择
    if args.reset:
        if os.path.exists(USER_SELECTED_CONNECTION_PATH):
            os.remove(USER_SELECTED_CONNECTION_PATH)
            print('已重置连接选择')
        connection_name = None
    
    # 如果没有指定连接，尝试使用用户上次选择的连接
    if not connection_name:
        user_selected = get_user_selected_connection()
        if user_selected and user_selected in connections:
            connection_name = user_selected
    
    # 如果还是没有连接，使用默认连接
    if not connection_name:
        for name, config in connections.items():
            if config.get('default', False):
                connection_name = name
                break
        
        if not connection_name:
            print('[错误] 没有指定连接且无可用连接')
            print('可用连接:', ', '.join(connections.keys()))
            sys.exit(1)
    
    # 验证连接存在
    if connection_name not in connections:
        print(f'[错误] 连接 "{connection_name}" 不存在')
        print('可用连接:', ', '.join(connections.keys()))
        sys.exit(1)
    
    # 保存用户选择的连接
    save_user_selected_connection(connection_name)
    
    conn_info = connections[connection_name]
    print(f'正在使用 SAP 连接：{connection_name}')
    print(f'  服务器：{conn_info.get("ASHOST", "N/A")}')
    print(f'  实例：{conn_info.get("SYSNR", "N/A")}')
    print(f'  客户端：{conn_info.get("CLIENT", "N/A")}')
    print(f'  用户：{conn_info.get("USER", "N/A")}')
    
    try:
        result = execute_report(
            report=args.report,
            variant=args.variant,
            max_rows=args.max_rows,
            it_params=it_params,
            connection_name=connection_name,
        )
    except Exception as e:
        error_result = {'status': 'error', 'message': f'连接或执行失败：{str(e)}'}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)
    
    ev_subrc = result['EV_SUBRC']
    ev_message = result['EV_MESSAGE']
    et_columns = result['ET_COLUMNS']
    et_data = result['ET_DATA']
    
    print(f'返回码：{ev_subrc}')
    print(f'消息：{ev_message}')
    print(f'数据行数：{len(et_data)}')
    print(f'字段目录数：{len(et_columns)}')
    
    if ev_subrc != 0:
        error_result = {'status': 'error', 'subrc': ev_subrc, 'message': ev_message}
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)
    
    if not et_data:
        print('无数据返回')
        sys.exit(0)
    
    rows_parsed, header_texts = parse_alv_data(et_columns, et_data)
    fieldnames = [c['FIELDNAME'] for c in et_columns] if et_columns else ['LINE']
    
    print(f'解析后行数：{len(rows_parsed)}, 字段数：{len(fieldnames)}')
    
    output_file = export_excel(rows_parsed, fieldnames, header_texts, args.output_dir, args.report, args.variant)
    
    result_summary = {
        'status': 'success',
        'connection': connection_name,
        'report': args.report,
        'variant': args.variant,
        'subrc': ev_subrc,
        'message': ev_message,
        'total_rows': len(rows_parsed),
        'total_columns': len(fieldnames),
        'excel_file': output_file,
    }
    print(json.dumps(result_summary, ensure_ascii=False, indent=2))
    print(f'\nSAP 系统：{connection_name}')


if __name__ == '__main__':
    main()
